<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <link rel="icon" href="<?php echo e(url('images/favicon/favicon-32x32.png')); ?>" sizes="32x32">
        <link rel="apple-touch-icon-precomposed" href="<?php echo e(url('images/favicon/favicon-32x32.png')); ?>">
        <!-- META DATA-->
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="msapplication-tap-highlight" content="no">
        <meta name="title" content="Forge Admin is modern, responsive Material Admin Template.">
        <meta name="description" content="Forge Admin Material Admin Template is modern, responsive and based on Material Design by Google.It's Material Design Admin Template powered by MaterialCSS.">
        <meta name="keywords" content="materialize, admin template, dashboard template, flat admin template, responsive admin template, materialcss, admin pages, material CMS, Forge Admin template, resoponsive material admin">
        <meta name="msapplication-TileColor" content="#FFFFFF">
        <meta name="msapplication-TileImage" content="<?php echo e(url('images/favicon/favicon-32x32.png')); ?>">
        <meta name="theme-color" content="#EE6E73">



        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Forge Admin')); ?></title>
        <!-- FONTS-->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata" type="text/css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/dynamic.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('plugins/scrollbar/perfect-scrollbar.min.css')); ?>">
        <link href="<?php echo e(asset('css/admin/app.css')); ?>" rel="stylesheet">
        <?php echo $__env->yieldContent('css'); ?>
    </head>
    <body class="signin">
        <?php echo $__env->yieldContent('appPre'); ?>
        <div id="app">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php echo $__env->yieldContent('appPost'); ?>
        <!-- Scripts -->
        <script type="text/javascript" src="<?php echo e(asset('js/all.js')); ?>"></script>

        <?php echo $__env->yieldContent('jsPreApp'); ?>
        
        <script src="<?php echo e(asset('js/forge.js')); ?>"></script>
        <script src="<?php echo e(asset('js/signin.js')); ?>"></script>
        <script src="<?php echo e(asset('js/init.js')); ?>"></script>
        <?php echo $__env->yieldContent('jsPostApp'); ?>
    </body>
</html>
