<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsPostApp'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-container">
<div class="card small" style="padding:30px;">
    <form class="row" style="padding:100px;" action="<?php echo e(url('admin/changefee')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="col-md-2 col m2" style="text-align:right;">
            Fee Price : 
        </div>
        <div class="col-md-2 col m2">
            <input name="price" type="number" placeholder="PRICE OF FEE" value="<?php echo e($fee->price); ?>">
        </div>
        <div class="col-md-2 col m2" style="text-align:right;">
            Fee Status : 
        </div>
        <div class="col-md-2 col m2">
            <div class="switch">
                <label>
                    Off
                    <input type="checkbox" name="status" <?php if($fee->status == 1){echo 'checked';}?> value="1">
                    <span class="lever"></span>
                    On
                </label>
            </div>
        </div>
        <div class="col-md-2 col m2">
            <button class="waves-effect waves-light btn-large black">Set</button> 
        </div>
        <div class="col-md-2 col m2">
        </div>
    </form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>