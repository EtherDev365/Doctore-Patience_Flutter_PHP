
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-container">

    <div class="row">
        <div class="col s6 m3">
            <div class="card">
                <div class="card-content">
                    <span class="card-title">New Doctor - Activation Process</span>
                    <?php $g = 1;$k=1;foreach($doctors as $doctor){?>
                        <div class="row linkprofile">
                            <input type="hidden" value="#profile<?php echo e($g); ?>">
                            <div class="col m3">
                                <img src="<?php echo e(asset('upload/photo/'.$doctor->photo)); ?>" style="width:50px;height:50px;border-radius: 100%;">
                            </div>
                            
                            <div class="col m9">
                                <p><?php echo e($doctor->fname); ?> <?php echo e($doctor->lname); ?></p>
                                <p><?php echo e($doctor->country); ?> <?php echo e($doctor->city); ?> <?php echo e($doctor->area); ?></p>
                            </div>
                        </div>
                        <?php $k=$g;$g++;}?>
                </div>
            </div>
        </div>
        <div class="col s18 m9">
            <div class="card">
                <div class="card-content">
                <?php $g =1;foreach($doctors as $doctor) {?>
                        <div class="bigphoto" id="profile<?php echo e($g); ?>" style="display:none">
                            <div style="padding:10px">
                                <div class="row">
                                    <div class="col m6">
                                        <span>First Name</span>
                                    </div>
                                    <div class="col m6">
                                        <span><?php echo e($doctor->fname); ?></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Last Name</span>
                                    </div>
                                    <div class="col m6">
                                        <span><?php echo e($doctor->lname); ?></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Degree</span>
                                    </div>
                                    <div class="col m6">
                                        <span><?php echo e($doctor->degree); ?></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Menulist</span>
                                    </div>
                                    <div class="col m6">
                                        <span><?php echo e($doctor->menulist); ?></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Specialist</span>
                                    </div>
                                    <div class="col m6">
                                        <span><?php echo e($doctor->specialist1); ?></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Profile Photo</span>
                                    </div>
                                    <div class="col m6">
                                    <img src="<?php echo e(asset('upload/photo/'.$doctor->photo)); ?>" style="width:100px;height:100px;border-radius: 100%;">
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Authorization</span>
                                    </div>
                                    <div class="col m6">
                                        <span><?php echo e($doctor->authorization_no); ?></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Phone Number</span>
                                    </div>
                                    <div class="col m6">
                                        <span><?php echo e($doctor->phone); ?></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Email</span>
                                    </div>
                                    <div class="col m6">
                                        <span><?php echo e($doctor->email); ?></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>FaceBook Link</span>
                                    </div>
                                    <div class="col m6">
                                        <span><a href="<?php echo e($doctor->facebook_link); ?>"><?php echo e($doctor->facebook_link); ?></a></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Twitter Link</span>
                                    </div>
                                    <div class="col m6">
                                        <span><a href="<?php echo e($doctor->twitter_link); ?>"><?php echo e($doctor->twitter_link); ?></a></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Instagram Link</span>
                                    </div>
                                    <div class="col m6">
                                        <span><a href="<?php echo e($doctor->instagram_link); ?>"><?php echo e($doctor->instagram_link); ?></a></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Youtube Link</span>
                                    </div>
                                    <div class="col m6">
                                        <span><a href="<?php echo e($doctor->youtube_link); ?>"><?php echo e($doctor->youtube_link); ?></a></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Office Address</span>
                                    </div>
                                    <div class="col m6">
                                        <span><?php echo e($doctor->office_address); ?></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Country</span>
                                    </div>
                                    <div class="col m6">
                                        <span><?php echo e($doctor->country); ?></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>City</span>
                                    </div>
                                    <div class="col m6">
                                        <span><?php echo e($doctor->city); ?></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Area</span>
                                    </div>
                                    <div class="col m6">
                                        <span><?php echo e($doctor->area); ?></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Doctor CV</span>
                                    </div>
                                    <div class="col m6">
                                        <span><?php echo e($doctor->doctor_cv); ?></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Video Photo</span>
                                    </div>
                                    <div class="col m6">
                                    <img src="<?php echo e(asset('upload/videophoto/'.$doctor->video_photo)); ?>" style="width:100px;height:100px;border-radius: 10%;">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Video Link</span>
                                    </div>
                                    <div class="col m6">
                                        <span><a href="<?php echo e($doctor->video_link); ?>"><?php echo e($doctor->video_link); ?></a></span>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                                <div class="row">
                                    <div class="col m6">
                                        <span>Register Fee Status</span>
                                    </div>
                                    <div class="col m6">
                                        <?php if($doctor->fee == 11){?>
                                        <span>Paid</span>
                                        <?php }else if($doctor->fee == 10){?>
                                        <span>unPaid with Enable</span>
                                        <?php }else{?>
                                        <span>unPaid with Disable</span>
                                        <?php }?>
                                    </div>
                                </div>
                                <div style="height: 1px; background: #EFEFF4;"></div>
                            </div>
                            <div class="row">
                                <div class="col m4" style="text-align:left">
                                    <?php if($g > 1){?>
                                    <a class="waves-effect waves-light btn-large linkprofile"><i class="material-icons left">skip_previous</i>Previous Dr</a>
                                    <input type="hidden" value="#profile<?php echo e($g-1); ?>">
                                    <?php }?>
                                </div>
                                <div class="col m4" style="text-align:center">
                                    <a class="waves-effect waves-light btn-large black declinedoctor">Decline</a> 
                                    <input type="hidden" value="<?php echo e($doctor->id); ?>">
                                </div>
                                <div class="col m4" style="text-align:right">
                                    <?php if($g < $k){?>
                                    <a href="#three" class="waves-effect waves-light btn-large linkprofile"><i class="material-icons right">skip_next</i>Next Dr</a>
                                    <input type="hidden" value="#profile<?php echo e($g+1); ?>">
                                    <?php }?>
                                </div>   
                            </div>
                        </div>
                <?php $g++;}?>
                </div>
            </div>
        </div>
    </div>
</div>
<input id="saveid"  type="hidden">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $('.linkprofile').on('click',function(){
        var id = $(this).find('input').val();
        $('.showphoto').hide();
        $('.bigphoto').removeClass('showphoto');
        $(id).addClass('showphoto');
        $(id).show();
    });
    $('.declinedoctor').on('click',function(){
        var id = $(this).next('input').val();
        $(this).addClass("declineapproved");
        $('#saveid').val(id);
        $.ajax({
            type:'post',
            url:'/admin/declinedoctor',
            data: {
                "doctor_id":  $('#saveid').val(),
                "_token": $('meta[name="csrf-token"]').attr('content'),
            },
            success:function(data) {                  
                $('.declineapproved').removeClass('declinedoctor');
                $('.declineapproved').text('Declined');
            },
            failure:function(){
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>