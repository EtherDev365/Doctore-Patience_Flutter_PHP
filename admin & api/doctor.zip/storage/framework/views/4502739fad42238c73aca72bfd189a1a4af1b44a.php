<?php $__env->startSection('content'); ?>
<div class="main-container">
    <div class="row" style="margin-top:10px !important;">
        
        <div class="col s12">
            <?php echo $__env->make('flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        
        <form class="col m6 s12 profile-info-form" role="form" method="POST" action="<?php echo e(url('/admin/profile/'.auth()->user()->id)); ?>" enctype="multipart/form-data">
            <?php echo e(method_field('PUT')); ?>

            <?php echo e(csrf_field()); ?>

            <div class="card-panel profile-form-cardpanel">
                <div class="row box-title">
                    <div class="col s12">
                        <h5>Profile Information</h5>
                    </div>
                </div>
                <div class="row">
                    
                    <div class="input-field col s12">
                        <i class="material-icons prefix">person</i>
                        <input type="text" id="name" name="name" value="<?php echo e(auth()->user()->name); ?>" autofocus>
                        <label for="name">Name</label>
                        <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="input-field col s12">
                        <i class="material-icons prefix">bookmark</i>
                        <input class="validate" type="text" id="designation" name="designation" value="<?php echo e(auth()->user()->designation); ?>" autofocus>
                        <label for="name">designation</label>
                        <?php if($errors->has('designation')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('designation')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="input-field col s12">
                        <i class="material-icons prefix">email</i>
                        <input class="validate" type="email" id="email" name="email" value="<?php echo e(auth()->user()->email); ?>" autofocus>
                        <label for="email">Email</label>
                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="input-field col s12">
                    <img-fileinput imgsrc="<?php echo e(url('/upload/image/'.Auth::user()->pic)); ?>"></img-fileinput>
                        <?php if($errors->has('pic')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('pic')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="input-field col s12 right-align">
                    <button class="btn waves-effect waves-set" type="submit" name="update_profile">Update<i class="material-icons right">save</i>
                    </button>
                    </div>
                </div>
            </div>
        </form>
        
        <form class="col m6 s12 profile-info-form" role="form" method="POST" action="<?php echo e(url('/admin/changepassword/'.auth()->user()->id)); ?>">
            <?php echo e(method_field('PUT')); ?>

            <?php echo e(csrf_field()); ?>

            <div class="card-panel profile-form-cardpanel">
                <div class="row box-title">
                    <div class="col s12">
                        <h5>Change Password</h5>
                    </div>
                </div>
                <div class="row">
                    
                    <div class="input-field col s12">
                        <input class="validate" type="password" id="oldpassword" name="oldpassword" autofocus>
                        <label for="name">Old Password</label>
                        <?php if($errors->has('oldpassword')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('oldpassword')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="input-field col s12">
                        <input class="validate" type="password" id="password" name="password" autofocus>
                        <label for="name">New Password</label>
                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="input-field col s12">
                        <input class="validate" type="password" id="password_confirmation" name="password_confirmation" autofocus>
                        <label for="password_confirmation">Confirm Password</label>
                        <?php if($errors->has('password_confirmation')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="input-field col s12 right-align">
                    <button class="btn waves-effect waves-set" type="submit" name="update_profile">Change Password<i class="material-icons right">save</i>
                    </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>