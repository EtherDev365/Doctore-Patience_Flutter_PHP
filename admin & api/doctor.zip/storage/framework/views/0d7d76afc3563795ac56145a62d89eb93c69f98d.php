<?php $__env->startSection('csscontent'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

              <div class="col-lg">
                <div class="tabContentCol">
                  <div class="tab-content">
                  <div class="tab-pane fade show active">
                    <div class="tabheaderCol">
                      <h2><img src="<?php echo e(asset('addbyme/images/key.png')); ?>" alt="..." style="width:40px;height:40px;">  ﺗﻐﻴﻴﺮ ﻛﻠﻤﺔ ﺍﻟﻤﺮﻭﺭ</h2>
                    </div>
                    <?php if($error != 'no'){?>
                    <form class="tabDetailCol" method="POST" action="<?php echo e(url('ppassword')); ?>" id="updatepasswordform" >
                      <?php echo csrf_field(); ?>
                      <div class="formInfo pdCol">
                        <h3 class="tabTitle" style="color:red;"><?php echo e($error); ?></h3>
                        <div class="row rowCol">
                          <div class="col-md-8">
                            <div class="form-group">
                                <label for="password">ﻛﻠﻤﺔ ﺍﻟﻤﺮﻭﺭ ﺍﻟﺤﺎﻟﻴﺔ</label>
                                <div class="formStyle inputIcol bothSideIcon">
                                    <input type="password" class="form-control" name="current" id="myFunction1" required>
                                    <span class="InputIcon">
                                        <img src="<?php echo e(asset('addbyme/images/password-lock.svg')); ?>" alt="...">
                                    </span>
                                    <div  onclick="myFunction1()">
                                        <img src="<?php echo e(asset('addbyme/images/eye-show.svg')); ?>" alt="..." class="InputIcon iconRight" style="left: 20px;right: auto;">
                                    </div>
                                </div>
                            </div>
                          </div>
                          <div class="col-md-4">
                          
                          </div>
                          <div class="col-md-8">
                            <div class="form-group">
                                <label for="password">ﻛﻠﻤﺔ ﺍﻟﻤﺮﻭﺭ ﺍﻟﺠﺪﻳﺪﺓ</label>
                                <div class="formStyle inputIcol bothSideIcon">
                                    <input type="password" class="form-control" name="new" id="myFunction2" required>
                                    <span class="InputIcon">
                                        <img src="<?php echo e(asset('addbyme/images/password-lock.svg')); ?>" alt="...">
                                    </span>
                                    <div  onclick="myFunction2()">
                                        <img src="<?php echo e(asset('addbyme/images/eye-show.svg')); ?>" alt="..." class="InputIcon iconRight" style="left: 20px;right: auto;">
                                    </div>
                                </div>
                            </div>
                          </div>
                          <div class="col-md-4">
                          </div>
                          <div class="col-md-8">
                            <div class="form-group">
                                <label for="password">ﺗﺄﻛﻴﺪ ﻛﻠﻤﺔ ﺍﻟﻤﺮﻭﺭ ﺍﻟﺠﺪﻳﺪﺓ</label>
                                <div class="formStyle inputIcol bothSideIcon">
                                    <input type="password" class="form-control" id="myFunction3" required>
                                    <span class="InputIcon">
                                        <img src="<?php echo e(asset('addbyme/images/password-lock.svg')); ?>" alt="...">
                                    </span>
                                    <div  onclick="myFunction3()">
                                        <img src="<?php echo e(asset('addbyme/images/eye-show.svg')); ?>" alt="..." class="InputIcon iconRight" style="left: 20px;right: auto;">
                                    </div>
                                </div>
                            </div>
                          </div>
                        </div>
                      </div>
                        <div class="tabBtn text-center">
                          <button class="btn btnStyle btn_primarySecond" >ﺗﺄﻛﻴﺪ ﺗﻐﻴﻴﺮ ﻛﻠﻤﺔ ﺍﻟﻤﺮﻭﺭ</button>
                        </div>
                      </div>
                    </form>
                    <?php }else {?>
                          <div class="tabDetailCol row" style="text-align:center;">
                              <div class="col-md-2">
                              </div>
                              <div class="col-md-8">
                              <div style="padding:30px;background-color:#FDFDFD;border: 1px solid #E9E9E9;box-sizing: border-box;border-radius: 38px;">
                              <img src="<?php echo e(asset('addbyme/images/afterchangepassword.png')); ?>"></br></br>
                              ﺗﻢ ﺗﻐﻴﻴﺮ ﻛﻠﻤﺔ ﺍﻟﻤﺮﻭﺭ ﺑﻨﺠﺎﺡ
                              </div>
                              </div>
                              <div class="col-md-2">
                              </div>
                          </div>
                    <?php }?>
                  </div>
                </div>
                </div>
              </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jscontent'); ?>
    <script>
        $('#updatepasswordform').submit(function(){
            if($('#myFunction2').val() == $('#myFunction3').val())
                return true;
            alert('الرمز السري الذي تم ادخاله مختلف، يرجى التأكد منه والمحاولة مرة أخرى');
            return false;
        });
        setInterval(function(){
                $.ajax({
                    type: "GET",
                    url: '/getpunreadmessage',
                    success: function(data){
                        $('.unreadcount').text(data);
                    }
                });
    },3000);  
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apppatient', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>