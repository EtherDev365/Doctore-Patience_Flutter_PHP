<?php $__env->startSection('csscontent'); ?>
<style>
    .chatone{
        border: 0;
        padding: 10px 20px 10px 20px;
        border-radius: 5px;
        max-inline-size: min-content;
        min-width:70%;
        font-size:18px;
        color:#117E3D;
        background-color:white;
    }
    .chattwo{
        border: 0;
        padding: 10px 20px 10px 10px;
        border-radius: 5px;
        max-inline-size: min-content;
        min-width:70%;
        font-size:18px;
        color:#18468B;
        background-color:white;
    }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

              <div class="col-lg">
                <div class="tabContentCol">
                  <div class="tab-content">
                  <div class="tab-pane fade show active">
                    <div class="tabheaderCol">
                      <h2><img src="<?php echo e(asset('addbyme/images/message.png')); ?>" alt="..." style="width:40px;height:40px;">   ﺍﺳﺘﺸﺎﺭﺓ ﻛﺘﺎﺑﻴﺔ</h2>
                    </div>
                    <div class="row" style="padding:10px 30px;">
                        <div class="col-md-2 col-5">
                        <img src="<?php echo e(asset('upload/photo/doctor.png')); ?>" alt="..." style="border-radius:100%;max-width:70px;height:70px;    border-style: ridge;">
                        </div>
                        <div class="col-md-10 col-7" style="padding:inherit">Haydar Jomaa </br>Dentist  </div>
                    </div>
                    <div class="tabDetailCol" style="border-bottom: black;padding: 20px; background-color:#E8EFF5;     max-height: 800px;overflow-y: scroll;overflow-x: hidden;direction: ltr; border-style: inset;" id="sliberbox">
                    <div class="row" style="direction: rtl;" id="chatbox">
                    
                        <div class="col-md-12">
                            <p class="chatone">
                            ﻳﻤﻜﻨﻚ ﺍﺭﺳﺎﻝ ﺳﺆﺍﻟﻚ ﺍﻵﻥ ﻭﺗﻔﺎﺻﻴﻞ ﺣﺎﻟﺘﻚ</br><span style="font-size: small;">2020-05-14 09:37:53
                            <img src="<?php echo e(asset('addbyme/images/unread.png')); ?>" alt="...">
                            </br>
                            </span></p>
                        </div>
                        <div class="col-md-12">
                            <p class="chatone">
                            ﻛﻤﺎ ﻳﻤﻜﻨﻚ ﺍﺭﺳﺎﻝ ﺍﻟﻤﻠﻔﺎﺕ ﺍﻭ ﺻﻮﺭﺓ</br><span style="font-size: small;">2020-05-14 09:37:53
                            <img src="<?php echo e(asset('addbyme/images/unread.png')); ?>" alt="...">
                            </br>
                            </span></p>
                        </div>
                        <div class="col-md-12" style="direction: ltr;">
                            <p class="chattwo" >
                            ﻳﻤﻜﻨﻚ ﺍﺭﺳﺎﻝ ﺳﺆﺍﻟﻚ ﺍﻵﻥ ﻭﺗﻔﺎﺻﻴﻞ ﺣﺎﻟﺘﻚ</br><span style="font-size: small;">2020-05-14 09:37:53
                            <img src="<?php echo e(asset('addbyme/images/unread.png')); ?>" alt="...">
                            </br>
                            </span></p>
                        </div>
                        <div class="col-md-12" style="direction: ltr;">
                            <p class="chattwo">
                            ﻛﻤﺎ ﻳﻤﻜﻨﻚ ﺍﺭﺳﺎﻝ ﺍﻟﻤﻠﻔﺎﺕ ﺍﻭ ﺻﻮﺭﺓ</br><span style="font-size: small;">2020-05-14 09:37:53
                            <img src="<?php echo e(asset('addbyme/images/unread.png')); ?>" alt="...">
                            </br>
                            </span></p>
                        </div>
                    </div>
                    </div>
                    <input type="file" name="photo" style="display:none;"  data-input="false"  data-size="sm" data-badge="false"  accept="image/*">
                    <div class="tabDetailCol row" style="border-bottom: black;padding: 20px;   border-style: inset;">
                        <div class="col-md-2" style="padding: inherit;">
                            <div class="formStyle">
                                <img src="<?php echo e(asset('addbyme/images/messagebox.png')); ?>" alt="..." >
                            </div>
                        </div>
                        <div class="col-md-10">
                            <div class="formStyle">
                                <textarea  class="form-control"  placeholder="" name="name" placeholder="Text" required style="height:150px;font-size:18px;" id="messagetext"></textarea>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="formStyle">
                                <a id="bt_patient_image"><img src="<?php echo e(asset('addbyme/images/attached.png')); ?>" alt="..." ></a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="formStyle">
                                <input type="input" class="form-control" id="filename"  placeholder=""required readonly>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="formStyle">
                            <input type="button" class="form-control" id="sendmessage"  placeholder="" name="name" value="ﺍﻧﻬﺎﺀ ﺍﻻﺳﺘﺸﺎﺭﺓ" required style="background-color:yellow;">
                            </div>
                        </div>
                    </div>
                  </div>
                </div>
                </div>
              </div>
    <?php if($statusone == 'good'){?>
    <a data-toggle="modal" data-target="#addmoneymodaldiv" id="addmoneymodal" style="display:none;"></a>
    <div class="modal fade sign-in-modal3 rounded-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="addmoneymodaldiv">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="content-box">
              <div class="checkCol">
                <img src="<?php echo e(asset('addbyme/images/warning.png')); ?>" alt="..."> ﻑﺎﻛ ﺪﻴﺻﺭ ﻚﻳﺪﻟ ﺪﺟﻮﻳ ﻻ
              </div>
              <div class="appDetail" style="background:none;">
                <div class="appInfoCol">
                  <div class="appCol">
                    <a href="<?php echo e(url('/addmoney')); ?>" style="background-color:#1955A5;padding:10px;border-radius: 20px;color:white;">
                        <img src="<?php echo e(asset('addbyme/images/addmoney.png')); ?>"> ﺪﻴﺻﺭ ﺔﻓﺎﺿﺍ
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
    <?php }?>
    <?php if($statusone == 'bad'){?>
    <a data-toggle="modal" data-target="#addmoneymodaldiv" id="addmoneymodal" style="display:none;"></a>
    <div class="modal fade sign-in-modal3 rounded-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="addmoneymodaldiv">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="content-box">
              <div class="checkCol">
                <img src="<?php echo e(asset('addbyme/images/warning.png')); ?>" alt="...">  ﻋﺬﺭﺍ ﺳﻴﺘﻢ ﻗﺮﻳﺒﺎ ﺗﻔﻌﻴﻞ ﺧﺎﺻﻴﺔ ﺍﻻﺗﺼﺎﻝ ﺑﺎﻟﻄﺒﻴﺐ ﺑﺎﻟﺼﻮﺕ ﻭﺍﻟﺼﻮﺭﺓ
              </div>
              <div class="appDetail" style="background:none;">
                <div class="appInfoCol">
                  <div class="appCol">
                    <a href="<?php echo e(url('/createmessage/'.$id)); ?>" style="background-color:#00A68C;padding:10px;border-radius: 20px;color:white;">
                        <img src="<?php echo e(asset('addbyme/images/message.png')); ?>"> ﺍﺳﺄﻝ ﺍﻟﻄﺒﻴﺐ ﻛﺘﺎﺑﺔ
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
    <?php }?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jscontent'); ?>
    <script>
    $('#addmoneymodal').click();
    setInterval(function(){
                $.ajax({
                    type: "GET",
                    url: '/getpunreadmessage',
                    success: function(data){
                        $('.unreadcount').text(data);
                    }
                });
    },3000);  
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.apppatient', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>