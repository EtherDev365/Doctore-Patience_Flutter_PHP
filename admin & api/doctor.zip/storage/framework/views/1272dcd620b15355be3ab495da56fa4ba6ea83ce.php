<?php $__env->startSection('csscontent'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

               <div class="col-lg">
                <div class="tabContentCol">
                  <div class="tab-content">
                  <div class="tab-pane show active">
                    <div class="tabheaderCol">
                      <h2>اتصل بالإدارة</h2>
                    </div>
                    <div class="tabDetailCol">
                      <div class="tableSecTab">
                        <div class="table-responsive">
                            <form method="POST" action="<?php echo e(url('dcontactus')); ?>">
                            <?php echo csrf_field(); ?>
                                <div style="padding:10px 0px;">
                                    <input type="text" name="title" style="width:40%;background-color:#DEDEDE;border-radius: 10px; padding: 5px 30px;" placeholder="الاسم">
                                </div>
                                <div >
                                    <textarea name="message" style="width:100%;background-color:#DEDEDE;border-radius: 10px; padding: 15px 30px;" rows="5" placeholder="نص الرسالة"></textarea>
                                </div>
                                <div style="text-align:center;">
                                    <input type="submit" value="ارسال" style="padding: 10px 30px;border-radius: 10px; background-color: #FFC80A;">
                                </div>
                            </form>
                        </div>
                      </div>

                    </div>
                  </div>
                </div>
                </div>
              </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jscontent'); ?>
    <script>
setInterval(function(){
                $.ajax({
                    type: "GET",
                    url: '/getdunreadmessage',
                    success: function(data){
                        $('.unreadcount').text(data);
                    }
                });
    },3000); 
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appdoctor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>