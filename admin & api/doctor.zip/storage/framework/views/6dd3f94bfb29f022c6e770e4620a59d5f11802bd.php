<?php $__env->startSection('csscontent'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

              <div class="col-lg">
                <div class="tabContentCol">
                  <div class="tab-content">
                  <div class="tab-pane fade show active">
                    <div class="tabheaderCol">
                      <h2><img src="<?php echo e(asset('addbyme/images/profile.png')); ?>" alt="..." style="width:40px;height:40px;">  ﺍﻟﻤﻠﻒ ﺍﻟﺸﺨﺼﻲ</h2>
                    </div>
                    <form class="tabDetailCol" method="POST" action="<?php echo e(url('pupdateprofile')); ?>"  enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                      <input type="file" name="photo" style="display:none;">
                      <div class="formInfo pdCol">
                        <h3 class="tabTitle">بيانات الملف الشخصي</h3>
                        <div class="row rowCol">
                          <div class="col-md-6">
                            <div class="form-group formGroup tabInputStyle">
                              <label >الاسم الكامل</label>
                              <div class="formStyle">
                                <input type="text" class="form-control"  placeholder="" name="name" value="<?php echo e($patient->name); ?>" required>
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group formGroup tabInputStyle">
                              <label >البريد الإلكتروني</label>
                              <div class="formStyle">
                                <input type="email" class="form-control"  placeholder=""  name="email" value="<?php echo e($patient->email); ?>" required>
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group formGroup tabInputStyle">
                              <label >رقم الهاتف</label>
                              <div class="formStyle">
                                <input type="text" class="form-control" name="phone"  value="<?php echo e($patient->phone); ?>" required>
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group formGroup tabInputStyle">
                              <label >العنوان</label>
                              <div class="formStyle">
                                <input type="text" class="form-control" name="address"  value="<?php echo e($patient->address); ?>" required>
                              </div>
                            </div>
                          </div>
                          <div class="col-md-12">
                            <div class="form-group formGroup formtextarea">
                                <label >المزيد من المعلومات</label>
                                <div class="formStyle">
                                    <textarea  type="text" class="form-control"  placeholder="" required name="more_info"><?php echo e($patient->more_info); ?></textarea>
                                </div>
                            </div>
                          </div>
                        </div>
                      </div>
                        <div class="tabBtn text-center">
                          <button class="btn btnStyle btn_primarySecond" >تحديث</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
                </div>
              </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jscontent'); ?>
    <script>
    $('#bt_patient_image').on('click',function(){
        $('input[name="photo"]').click();
    });
    $('input[name="photo"]').on('change',function(e){
        var file = e.target.files[0];
        var reader = new FileReader();
        reader.onloadend =function(){
            $('#userimage').attr('src', reader.result);
        }
        reader.readAsDataURL(file);    
    });
    setInterval(function(){
                $.ajax({
                    type: "GET",
                    url: '/getpunreadmessage',
                    success: function(data){
                        $('.unreadcount').text(data);
                    }
                });
    },3000);  
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apppatient', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>