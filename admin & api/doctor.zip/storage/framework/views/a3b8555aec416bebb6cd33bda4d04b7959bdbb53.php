<?php $__env->startSection('csscontent'); ?>
<style>
    .chatone{
        border: 0;
        padding: 10px 20px 10px 20px;
        border-radius: 5px;
        max-inline-size: min-content;
        min-width:70%;
        font-size:18px;
        color:#117E3D;
        background-color:white;
    }
    .chattwo{
        border: 0;
        padding: 10px 20px 10px 10px;
        border-radius: 5px;
        max-inline-size: min-content;
        min-width:70%;
        font-size:18px;
        color:#18468B;
        background-color:white;
    }
    .noselected{
        display:none;
    }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

              <div class="col-lg">
                <div class="tabContentCol">
                  <div class="tab-content">
                  <div class="tab-pane fade show active">
                    <div class="tabheaderCol">
                      <h2><img src="<?php echo e(asset('addbyme/images/message.png')); ?>" alt="..." style="width:40px;height:40px;">   ﺍﺳﺘﺸﺎﺭﺓ ﻛﺘﺎﺑﻴﺔ</h2>
                    </div>
                    <div class="row" style="padding:10px 30px;">
                        <div class="col-md-2 col-5">
                        <img src="<?php echo e(asset('upload/photo/'.$doctor->photo)); ?>" alt="..." style="border-radius:100%;max-width:70px;height:70px;    border-style: ridge;">
                        </div>
                        <div class="col-md-10 col-7" style="padding:inherit"><?php echo e($doctor->fname); ?>  <?php echo e($doctor->lname); ?> </br><?php echo e($doctor->menulist); ?>  </div>
                    </div>
                    <div class="tabDetailCol" style="border-bottom: black;padding: 20px; background-color:#E8EFF5;     max-height: 800px;overflow-y: scroll;overflow-x: hidden;direction: ltr; border-style: inset;" id="sliberbox">
                    <div class="row" style="direction: rtl;" id="chatbox">
                    <?php foreach($chats as $chat){?>
                        <?php if($chat->who == 0 && $chat->type == 'text'){?>
                                <div class="col-md-12">
                                    <p class="chatone">
                                    <?php echo e($chat->text); ?></br><span style="font-size: small;"><?php echo e($chat->created_at); ?>

                                    <?php if($chat->status == "read"){?>
                                        <img src="<?php echo e(asset('addbyme/images/read.png')); ?>" alt="...">
                                    <?php } else {?>
                                        <img src="<?php echo e(asset('addbyme/images/unread.png')); ?>" alt="...">
                                    <?php }?></br>
                                    </span></p>
                                </div>
                        <?php } if($chat->who == 0 && $chat->type != 'text'){?>
                                <div class="col-md-12">
                                    <p class="chatone">
                                    <img src="<?php echo e(asset('upload/chat/'.$chat->text)); ?>"></br><span style="font-size: small;"><?php echo e($chat->created_at); ?>

                                    <?php if($chat->status == "read"){?>
                                        <img src="<?php echo e(asset('addbyme/images/read.png')); ?>" alt="...">
                                    <?php } else {?>
                                        <img src="<?php echo e(asset('addbyme/images/unread.png')); ?>" alt="...">
                                    <?php }?></br>
                                    </span></p>
                                </div>
                        <?php } if($chat->who == 1 && $chat->type == 'text'){?>
                                <div class="col-md-12" style="direction: ltr;">
                                    <p class="chattwo">
                                    <?php echo e($chat->text); ?></br><span style="font-size: small;"><?php echo e($chat->created_at); ?>

                                    <?php if($chat->status == "read"){?>
                                        <img src="<?php echo e(asset('addbyme/images/read.png')); ?>" alt="...">
                                    <?php } else {?>
                                        <img src="<?php echo e(asset('addbyme/images/unread.png')); ?>" alt="...">
                                    <?php }?>
                                    </span></p>
                                </div>
                        <?php } if($chat->who == 1 && $chat->type != 'text'){?>
                                <div class="col-md-12" style="direction: ltr;">
                                    <p class="chattwo">
                                    <img src="<?php echo e(asset('upload/chat/'.$chat->text)); ?>"></br><span style="font-size: small;"><?php echo e($chat->created_at); ?>

                                    <?php if($chat->status == "read"){?>
                                        <img src="<?php echo e(asset('addbyme/images/read.png')); ?>" alt="...">
                                    <?php } else {?>
                                        <img src="<?php echo e(asset('addbyme/images/unread.png')); ?>" alt="...">
                                    <?php }?></br>
                                    </span></p>
                                </div>
                    <?php } }?>
                    </div>
                    </div>
                    <input type="file" name="photo" style="display:none;"  data-input="false"  data-size="sm" data-badge="false"  accept="image/*">
                    <div class="tabDetailCol row" style="border-bottom: black;padding: 20px;   border-style: inset;">
                        <div class="col-md-2 col-3">
                            <div class="formStyle" style="display:flex">
                                <img src="<?php echo e(asset('addbyme/images/voicecall.png')); ?>" width="40px" alt="..." id="voicecall" style="margin-left:10px;">
                                <img src="<?php echo e(asset('addbyme/images/sendmessage.png')); ?>" width="40px" alt="..." id="sendmessage" style="margin-left:10px;">
                            </div>
                        </div>
                        <div class="col-md-10 col-9">
                            <div class="formStyle">
                                <a id="bt_patient_image" style="position: absolute; top: 5px; left: 5px;"><img src="<?php echo e(asset('addbyme/images/attach.png')); ?>" width="40px" alt="..." ></a>
                                <textarea  class="form-control"  placeholder="" name="name" placeholder="Text" required style="height:50px;font-size:18px;padding-left:50px;border-radius:5px" id="messagetext"></textarea>
                            </div>
                        </div>
                        <div class="col-md-8 col-9"style="margin-top: 20px;">
                            <div class="formStyle">
                                <input type="input" class="form-control" id="filename"  placeholder=""required readonly style="height:50px">
                            </div>
                        </div>
                        <div class="col-md-4" style="margin-top: 20px;">
                            <div class="formStyle">
                            <a data-toggle="modal" data-target="#addmoneymodaldiv" class="form-control"  placeholder="" name="name" value="" required style="background-color:#FFE380;;font-size:20px;border:none;height:50px"><p>ﺍﻧﻬﺎﺀ ﺍﻻﺳﺘﺸﺎﺭﺓ</p></a>
                            </div>
                        </div>
                    </div>
                  </div>
                </div>
                </div>
              </div>
              <input type="hidden" value="0" id="focusone">
                <div class="modal fade sign-in-modal3 rounded-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="addmoneymodaldiv">
                    <div class="modal-dialog modal-lg">
                    <div class="modal-content" style="width: fit-content;">
                        <div class="content-box">
                        <style>
                            .checkCol img {
                                width: 40px;
                            }
                            .appDetail {
                                background: white !important;
                                padding-top: 0px !important;
                            }
                            .appDetail .appCol {
                                max-width: 260px;
                            }
                        </style>
                        <div class="checkCol">
                            <img src="<?php echo e(asset('addbyme/images/aftermessage.png')); ?>" alt="..." style="width:100px">
                            <p style="margin-top:18px">ﺗﻢ ﺍﻧﻬﺎﺀ ﺍﻻﺳﺘﺸﺎﺭﺓ ﺑﻨﺠﺎﺡ</p>
                            <p>ﻛﻴﻒ ﺗﻘﻴﻢ ﺍﻻﺳﺘﺸﺎﺭﺓ؟</p>
                            <div class="starall star0">
                            <img src="<?php echo e(asset('addbyme/images/star1.png')); ?>" alt="..." class="starone"><input type="hidden" value="1">   
                            <img src="<?php echo e(asset('addbyme/images/star1.png')); ?>" alt="..." class="starone"><input type="hidden" value="2">    
                            <img src="<?php echo e(asset('addbyme/images/star1.png')); ?>" alt="..." class="starone"><input type="hidden" value="3">    
                            <img src="<?php echo e(asset('addbyme/images/star1.png')); ?>" alt="..." class="starone"><input type="hidden" value="4">    
                            <img src="<?php echo e(asset('addbyme/images/star1.png')); ?>" alt="..." class="starone"><input type="hidden" value="5">         
                            </div>
                            <div class="starall star1 noselected" >
                            <img src="<?php echo e(asset('addbyme/images/star2.png')); ?>" alt="..." class="starone"><input type="hidden" value="1">   
                            <img src="<?php echo e(asset('addbyme/images/star1.png')); ?>" alt="..." class="starone"><input type="hidden" value="2">    
                            <img src="<?php echo e(asset('addbyme/images/star1.png')); ?>" alt="..." class="starone"><input type="hidden" value="3">    
                            <img src="<?php echo e(asset('addbyme/images/star1.png')); ?>" alt="..." class="starone"><input type="hidden" value="4">    
                            <img src="<?php echo e(asset('addbyme/images/star1.png')); ?>" alt="..." class="starone"><input type="hidden" value="5">         
                            </div>
                            <div class="starall star2 noselected" >
                            <img src="<?php echo e(asset('addbyme/images/star2.png')); ?>" alt="..." class="starone"><input type="hidden" value="1">   
                            <img src="<?php echo e(asset('addbyme/images/star2.png')); ?>" alt="..." class="starone"><input type="hidden" value="2">    
                            <img src="<?php echo e(asset('addbyme/images/star1.png')); ?>" alt="..." class="starone"><input type="hidden" value="3">    
                            <img src="<?php echo e(asset('addbyme/images/star1.png')); ?>" alt="..." class="starone"><input type="hidden" value="4">    
                            <img src="<?php echo e(asset('addbyme/images/star1.png')); ?>" alt="..." class="starone"><input type="hidden" value="5">         
                            </div>
                            <div class="starall star3 noselected" >
                            <img src="<?php echo e(asset('addbyme/images/star2.png')); ?>" alt="..." class="starone"><input type="hidden" value="1">   
                            <img src="<?php echo e(asset('addbyme/images/star2.png')); ?>" alt="..." class="starone"><input type="hidden" value="2">    
                            <img src="<?php echo e(asset('addbyme/images/star2.png')); ?>" alt="..." class="starone"><input type="hidden" value="3">    
                            <img src="<?php echo e(asset('addbyme/images/star1.png')); ?>" alt="..." class="starone"><input type="hidden" value="4">    
                            <img src="<?php echo e(asset('addbyme/images/star1.png')); ?>" alt="..." class="starone"><input type="hidden" value="5">         
                            </div>
                            <div class="starall star4 noselected" >
                            <img src="<?php echo e(asset('addbyme/images/star2.png')); ?>" alt="..." class="starone"><input type="hidden" value="1">   
                            <img src="<?php echo e(asset('addbyme/images/star2.png')); ?>" alt="..." class="starone"><input type="hidden" value="2">    
                            <img src="<?php echo e(asset('addbyme/images/star2.png')); ?>" alt="..." class="starone"><input type="hidden" value="3">    
                            <img src="<?php echo e(asset('addbyme/images/star2.png')); ?>" alt="..." class="starone"><input type="hidden" value="4">    
                            <img src="<?php echo e(asset('addbyme/images/star1.png')); ?>" alt="..." class="starone"><input type="hidden" value="5">         
                            </div>
                            <div class="starall star5 noselected" >
                            <img src="<?php echo e(asset('addbyme/images/star2.png')); ?>" alt="..." class="starone"><input type="hidden" value="1">   
                            <img src="<?php echo e(asset('addbyme/images/star2.png')); ?>" alt="..." class="starone"><input type="hidden" value="2">    
                            <img src="<?php echo e(asset('addbyme/images/star2.png')); ?>" alt="..." class="starone"><input type="hidden" value="3">    
                            <img src="<?php echo e(asset('addbyme/images/star2.png')); ?>" alt="..." class="starone"><input type="hidden" value="4">    
                            <img src="<?php echo e(asset('addbyme/images/star2.png')); ?>" alt="..." class="starone"><input type="hidden" value="5">         
                            </div>
                        </div>
                        <div class="appDetail">
                            <div class="appInfoCol">
                            <form class="appCol"  method="POST" action="<?php echo e(url('givefeedback')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($consultant_id); ?>" name="consultant_id" id="saveid">
                                <input type="hidden" value="0" name="rate" id="starno">
                                <textarea style="width: 100%; height: 100px; border-radius:5px;margin-bottom: 10px" name="feedback" placeholder="ﺷﺎﺭﻛﻨﺎ ﺑﺘﺠﺮﺑﺘﻚ"></textarea>
                                <button class="btn btnStyle "  style="width:40%;margin-left:5%;border-radius: 40px;color:white;background-color:#00A68C;">ﺍﻟﻤﺘﺎﺑﻌﺔ</button>
                                <button class="btn btnStyle" data-dismiss="modal" aria-label="Close" style="width:40%;border-radius: 40px;color:white;background-color:#1861CE;">ﺍﻟﻐﺎﺀ ﺍﻷﻣﺮ</button>
                            </form>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jscontent'); ?>
    <script>
    var objDiv = document.getElementById("sliberbox");
    objDiv.scrollTop = objDiv.scrollHeight;
    $('.starone').click(function(){
        $('.starall').addClass('noselected');
        var i = $(this).next('input').val();
        $('.star'+i).removeClass('noselected');
        $('#starno').val(i);
    })
    $('#messagetext').click(function() { 
        $.ajax({
            type:'post',
            url:'/psetallstatus',
            data: {
                "consultant_id":  $('#saveid').val(),
                "_token": $('meta[name="csrf-token"]').attr('content'),
            },
            success:function(data) { 
            },
            failure:function(){
            }
        });
     });
    $( "#messagetext" ).keyup(function() {
        $.ajax({
            type:'post',
            url:'/psetallstatus',
            data: {
                "consultant_id":  $('#saveid').val(),
                "_token": $('meta[name="csrf-token"]').attr('content'),
            },
            success:function(data) { 
            },
            failure:function(){
            }
        });
    });
    $('#bt_patient_image').on('click',function(){
        $('input[name="photo"]').click();
    });
    $('input[name="photo"]').on('change',function(e){
        var file = e.target.files[0];
        var reader = new FileReader();
        reader.onloadend =function(){
            $('#filename').val(file.name);
        }
        reader.readAsDataURL(file);    
    });
    $('#sendmessage').on('click',function(){
        if($('#messagetext').val() != '')
        {
            var html = '';
            html += '<div class="col-md-12">';
            html += '<p class="chatone">'+$('#messagetext').val()+'</p>';
            html += '</div>';
            $('#chatbox').append(html);
            var objDiv = document.getElementById("sliberbox");
            objDiv.scrollTop = objDiv.scrollHeight;
            $.ajax({
                type:'post',
                url:'/psavechatone',
                data: {
                    "consultant_id":  $('#saveid').val(),
                    "text":  $('#messagetext').val(),
                    "type":  'text',
                    "_token": $('meta[name="csrf-token"]').attr('content'),
                },
                success:function(data) { 
                    $('#messagetext').val('');                 
                },
                failure:function(){
                }
            });
        }
        if($('#filename').val() !='')
        {
            var dataimg = new FormData();
            dataimg.append("consultant_id", $('#saveid').val());
            dataimg.append("text", $('input[name="photo"]')[0].files[0]);
            dataimg.append("type", $('#filename').val());
            dataimg.append("_token", $('meta[name="csrf-token"]').attr('content'));
            $.ajax({
                type:'post',
                url:'/psavechatone',
                cache : false,
                contentType : false,
                processType : false,
                processData: false,
                data: dataimg,
                success:function(data) { 
                    console.log(data);
                    var html = '';
                    html +='<div class="col-md-12">';
                    html +='<p class="chatone"><img src="http://localhost:8000/upload/chat/'+data+'" ></p>';
                    html +='</div>';
                    $('#filename').val('');
                    $('#chatbox').append(html);    
                    var objDiv = document.getElementById("sliberbox");
                    objDiv.scrollTop = objDiv.scrollHeight;             
                },
                failure:function(){
                }
            });
        }
    })
    
    setInterval(function(){
                $.ajax({
                    type: "GET",
                    url: '/getpunreadmessage',
                    success: function(data){
                        $('.unreadcount').text(data);
                    }
                });
    },3000);  
    setInterval(function(){
        $.ajax({
            type:'post',
            url:'/pgetchat',
            data: {
                "consultant_id":  $('#saveid').val(),
                "_token": $('meta[name="csrf-token"]').attr('content'),
            },
            success:function(data) { 
                var data = JSON.parse(data);
                var html ="";
                for(var i =0;i<data.length;i++)
                {
                    if(data[i]['who'] == 0 && data[i]['type'] == 'text'){
                        html +='<div class="col-md-12">';
                        html +='<p class="chatone">'+data[i]['text']+'</br><span style="font-size: small;">'+data[i]['created_at'];
                           if(data[i]['status'] == "read")
                           html +='<img src="http://localhost:8000/addbyme/images/read.png" alt="...">';
                           else
                           html +='<img src="http://localhost:8000/addbyme/images/unread.png" alt="...">';
                        
                        html +='</span></p>';
                        html +='</div>';
                    }
                    if(data[i]['who'] == 0 && data[i]['type'] != 'text'){
                        html +='<div class="col-md-12">';
                        html +='<p class="chatone"><img src="http://localhost:8000/upload/chat/'+data[i]['text']+'"></br><span style="font-size: small;">'+data[i]['created_at'];
                           if(data[i]['status'] == "read")
                           html +='<img src="http://localhost:8000/addbyme/images/read.png" alt="...">';
                           else
                           html +='<img src="http://localhost:8000/addbyme/images/unread.png" alt="...">';
                        
                        html +='</span></p>';
                        html +='</div>';
                    }
                    if(data[i]['who'] == 1 && data[i]['type'] == 'text'){
                        html +='<div class="col-md-12" style="direction: ltr;">';
                        html +='<p class="chattwo">'+data[i]['text']+'</br><span style="font-size: small;">'+data[i]['created_at'];
                            if(data[i]['status'] == "read")
                           html +='<img src="http://localhost:8000/addbyme/images/read.png" alt="...">';
                           else
                           html +='<img src="http://localhost:8000/addbyme/images/unread.png" alt="...">';
                        
                        html +='</span></p>';
                        html +='</div>';
                    }
                    if(data[i]['who'] == 1 && data[i]['type'] != 'text'){
                        html +='<div class="col-md-12" style="direction: ltr;">';
                        html +='<p class="chattwo"><img src="http://localhost:8000/upload/chat/'+data[i]['text']+'"></br><span style="font-size: small;">'+data[i]['created_at'];
                            if(data[i]['status'] == "read")
                           html +='<img src="http://localhost:8000/addbyme/images/read.png" alt="...">';
                           else
                           html +='<img src="http://localhost:8000/addbyme/images/unread.png" alt="...">';
                        
                        html +='</span></p>';
                        html +='</div>';
                    }
                }
                $("#chatbox").empty();
                $("#chatbox").append(html); 
                if($('#focusone').val() != data.length)
                {
                    $('#focusone').val(data.length);
                    var objDiv = document.getElementById("sliberbox");
                    objDiv.scrollTop = objDiv.scrollHeight;
                }
            },
            failure:function(){
            }
        });
    },3000);      
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.apppatient', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>