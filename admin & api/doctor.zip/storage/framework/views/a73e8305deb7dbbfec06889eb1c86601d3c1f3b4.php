<?php $__env->startSection('csscontent'); ?>
<style>
    .chatone{
        border: 0;
        padding: 10px 20px 10px 20px;
        border-radius: 5px;
        max-inline-size: min-content;
        min-width:70%;
        font-size:18px;
        color:#117E3D;
        background-color:white;
    }
    .chattwo{
        border: 0;
        padding: 10px 20px 10px 10px;
        border-radius: 5px;
        max-inline-size: min-content;
        min-width:70%;
        font-size:18px;
        color:#18468B;
        background-color:white;
    }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

              <div class="col-lg">
                <div class="tabContentCol">
                  <div class="tab-content">
                  <div class="tab-pane fade show active">
                    <div class="tabheaderCol">
                      <h2><img src="<?php echo e(asset('addbyme/images/bank.png')); ?>" alt="..." style="width:40px;height:40px;">ﻲﻜﻨﺒﻟﺍ ﻲﺑﺎﺴﺣ</h2>
                    </div>
                    <div class="row" style="padding:10px 30px;">
                        <div class="col-md-10 col-7" style="padding:inherit">:ﻲﻜﻨﺒﻟﺍ ﺏﺎﺴﺤﻟﺍ ﺕﺎﻧﺎﻴﺑ ﻝﺎﺧﺩﺍ ﻰﺟﺮﻳ</div>
                    </div>
                    <style>
                        .tabDetailCol input {
                            background:#F5F7ED;
                            border-radius:5px; 
                            height:50px;
                            width: 100%;
                            border: 1px solid #C5C5C5;
                            margin-bottom:5px;
                            padding: 5px;
                        }
                        .tabDetailCol button {
                            background:#4124F0;
                            height:50px;
                            border-radius:5px; 
                            width: 100%;
                            margin-bottom:20px;
                            color: white;
                        }
                    </style>
                    <div class="tabDetailCol" style="padding:10px">
                        <input type="text" placeholder="Account Number or IBAN">
                        <input type="text" placeholder="BIC/SWIFT">
                        <button class="btn">ﺚﻳﺪﺤﺗ</button>
                        <img src="<?php echo e(asset('addbyme/images/warning.png')); ?>" width="30px" alt="..." style="margin-left: 10px">ﺩﺭﺎﻛ ﺮﺘﺳﺎﻤﻟﺍ ﻭﺍ ﺍﺰﻴﻔﻟﺍ ﺔﻗﺎﻄﺒﻟ ﺭﺪﺼﻤﻟﺍ ﻚﻨﺒﻟﺍ ﻦﻣ ﺎﻬﻟﺎﺼﺤﺘﺳﺍ ﻦﻜﻤﻣ ﻩﻼﻋﺍ ﺕﺎﻧﺎﻴﺒﻟﺍ :ﺔﻈﺣﻼﻣ
                    </div>
                  </div>
                </div>
                </div>
              </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jscontent'); ?>
    <script>
    $('#addmoneymodal').click();
    setInterval(function(){
                $.ajax({
                    type: "GET",
                    url: '/getpunreadmessage',
                    success: function(data){
                        $('.unreadcount').text(data);
                    }
                });
    },3000);  
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.apppatient', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>