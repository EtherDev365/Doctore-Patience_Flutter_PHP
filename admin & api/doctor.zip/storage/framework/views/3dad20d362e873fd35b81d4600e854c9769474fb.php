<?php $__env->startSection('csscontent'); ?>
<style>
    .selected
    {
        background-color:#00B468!important;
        color:white!important;
        
    }
    @media(max-width:767px) {
        #cardone
        {
          text-align:center;
        }
        #cardone input
        {
          text-align:center;
        }
    }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

              <div class="col-lg">
                <div class="tabContentCol">
                  <div class="tab-content">
                  <div class="tab-pane fade show active">
                    <div class="tabheaderCol">
                      <h2><img src="<?php echo e(asset('addbyme/images/advice.png')); ?>" alt="..." style="width:40px;height:40px;">  ﺍﺿﺎﻓﺔ ﺭﺻﻴﺪ</h2>
                    </div>
                    <?php if($error == ''){?>
                    <form class="tabDetailCol" method="POST" action="<?php echo e(url('addmoneyaccount')); ?>"  enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                      <div class="pdCol" style="padding:0px 30px;">
                        <h3 class="tabTitle">الرصيد الحالي : <?php echo e($patient->money); ?>$</h3></br>
                        <h3 class="tabTitle" style="color:red;"><?php echo e($error); ?></h3>
                        <div class="row rowCol">
                          <div class="col-md-6" style="color:#4A7EE2">ﺍﺧﺘﺮ ﺑﺎﻗﺔ ﺍﻟﺮﺻﻴﺪ</div>
                          <div class="col-md-6" style="text-align:left">ﺍﻭ ﺍﻛﺘﺐ ﺍﻟﺮﺻﻴﺪ</div>
                        </div>
                        <div class="row rowCol">
                          <div class="col-md-3">
                            <div class="form-group formGroup tabInputStyle">
                              <div class="formStyle">
                                <input type="button" class="form-control selected selectedbutton"  placeholder="" name="name" value="10$" required>
                              </div>
                            </div>
                          </div>
                          <div class="col-md-3">
                            <div class="form-group formGroup tabInputStyle">
                              <div class="formStyle">
                                <input type="button" class="form-control selectedbutton"  placeholder="" name="name" value="20$" required>
                              </div>
                            </div>
                          </div>
                          <div class="col-md-3">
                            <div class="form-group formGroup tabInputStyle">
                              <div class="formStyle">
                                <input type="button" class="form-control selectedbutton"  placeholder="" name="name" value="30$" required>
                              </div>
                            </div>
                          </div>
                          <div class="col-md-3">
                            <div class="form-group formGroup tabInputStyle">
                              <div class="formStyle">
                                <input type="number" class="form-control selectedbutton"  value="" min="1">
                              </div>
                            </div>
                          </div>
                          <div class="row" style="background-color:#F7F7F7;border-radius: 10px;" id="cardone">
                            <div class="col-md-12" style="background-color:#FFCE00;border-radius: 10px;text-align:right;">
                                <div class="formGroup tabInputStyle" >
                                    <img src="<?php echo e(asset('addbyme/images/card5.png')); ?>" alt="slide_img" style="margin: 0.5rem;"> ﻣﻌﻠﻮﻣﺎﺕ ﺍﻟﺒﻄﺎﻗﺔ ﻟﻠﺪﻓﻊ ﺍﻻﻟﻜﺘﺮﻭﻧﻲ
                                </div>
                            </div>
                            <div class="col-md-1" style="padding-top: 1rem;">
                            </div>
                            <div class="col-md-2" style="padding-top: 1rem;">
                                <img src="<?php echo e(asset('addbyme/images/card1.png')); ?>" alt="slide_img" style="margin-top: 0.5rem;">
                            </div>
                            <div class="col-md-9" style="padding-top: 1rem;">
                                <div class="form-group formGroup tabInputStyle" style="max-width:100%;">
                                <div class="formStyle">
                                    <input type="text" class="form-control" name="cardname"  value="" required placeholder="Name on the Card" style="background-color:white;">
                                </div>
                                </div>
                            </div>
                            <div class="col-md-1">
                            </div>
                            <div class="col-md-2">
                                <img src="<?php echo e(asset('addbyme/images/card2.png')); ?>" alt="slide_img" style="margin-top: 0.5rem;">
                            </div>
                            <div class="col-md-9">
                                <div class="form-group formGroup tabInputStyle" style="max-width:100%;">
                                <div class="formStyle">
                                    <input type="text" class="form-control" name="cardnumber"  value="" required  placeholder="Card Number" style="background-color:white;">
                                </div>
                                </div>
                            </div>
                            <div class="col-md-1">
                            </div>
                            <div class="col-md-2">
                                <img src="<?php echo e(asset('addbyme/images/card3.png')); ?>" alt="slide_img" style="margin-top: 0.5rem;">
                            </div>
                            <div class="col-md-2">
                                <div class="form-group formGroup tabInputStyle">
                                <div class="formStyle">
                                    <input type="text" class="form-control" name="exp_year"  value="" required  placeholder="YY" style="background-color:white;padding:0px!important;    text-align: center;">
                                </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group formGroup tabInputStyle">
                                <div class="formStyle">
                                    <input type="text" class="form-control" name="exp_month"  value="" required  placeholder="MM" style="background-color:white;padding:0px!important;    text-align: center;">
                                </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <img src="<?php echo e(asset('addbyme/images/card4.png')); ?>" alt="slide_img" style="margin-top: 0.5rem;">
                            </div>
                            <div class="col-md-3">
                                <div class="form-group formGroup tabInputStyle">
                                <div class="formStyle">
                                    <input type="text" class="form-control" name="cvc"  value="" required  placeholder="CCV" style="background-color:white;">
                                </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="text-center">
                                    <button class="btn btnStyle btn_primarySecond" >ﺗﺄﻛﻴﺪ ﺩﻓﻊ  <span id="pricevalue">10$</span><img src="<?php echo e(asset('addbyme/images/payment.png')); ?>" alt="slide_img" ></button>
                                </div>
                            </div>
                            <div class="col-md-12" style="padding-bottom: 1rem;">
                                <div class="text-center">
                                    <img src="<?php echo e(asset('addbyme/images/visa.png')); ?>" alt="slide_img" style="margin-top: 0.5rem;">
                                </div>
                            </div>
                           </div>
                        </div>
                        <input type="hidden" name="amount" id="priceinput" value="10" required>
                    </form>
                    <?php }else if($error == 'no'){?>
                          <div class="tabDetailCol row" style="text-align:center;">
                              <div class="col-md-2">
                              </div>
                              <div class="col-md-8">
                              <div style="padding:30px;background-color:#FDFDFD;border: 1px solid #E9E9E9;box-sizing: border-box;border-radius: 38px;">
                              <img src="<?php echo e(asset('addbyme/images/afterchangepassword.png')); ?>"></br></br>
                              ﺗﻢ ﺍﺿﺎﻓﺔ ﺍﻟﺮﺻﻴﺪ ﺑﻨﺠﺎﺡ
                              </div>
                              </div>
                              <div class="col-md-2">
                              </div>
                          </div>
                    <?php } else {?>
                          <div class="tabDetailCol row" style="text-align:center;">
                              <div class="col-md-2">
                              </div>
                              <div class="col-md-8">
                              <div style="padding:30px;background-color:#FDFDFD;border: 1px solid #E9E9E9;box-sizing: border-box;border-radius: 38px;">
                              <img src="<?php echo e(asset('addbyme/images/warningx.png')); ?>"></br></br>
                              ﻳﺮﺟﻰ ﺍﻟﺘﺄﻛﺪ ﻣﻦ ﺍﻟﻤﻌﻠﻮﻣﺎﺕ
                              </br><a class="btn btnStyle" href="<?php echo e(url('/addmoney')); ?>" style="border-radius: 5px;color:white;background-color:#18A952;padding:12px;">ﺍﻋﺎﺩﺓ ﺍﻟﻤﺤﺎﻭﻟﺔ</a>
                              </div>
                              </div>
                              <div class="col-md-2">
                              </div>
                          </div>
                    <?php }?>
                  </div>
                </div>
                </div>
              </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jscontent'); ?>
    <script>
    $('.selectedbutton').on('click',function(){
        $('.selectedbutton').removeClass('selected');
        $(this).addClass('selected');
        $('#pricevalue').text($(this).val());
        $('#priceinput').val($(this).val());
    });
    $("input.selectedbutton").on('input',function(){
        $('#pricevalue').text($(this).val());
        $('#priceinput').val($(this).val());
    });
    setInterval(function(){
                $.ajax({
                    type: "GET",
                    url: '/getpunreadmessage',
                    success: function(data){
                        $('.unreadcount').text(data);
                    }
                });
    },3000);  
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apppatient', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>