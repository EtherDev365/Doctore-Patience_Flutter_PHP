<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <link rel="icon" href="<?php echo e(url('images/favicon/favicon-32x32.png')); ?>" sizes="32x32">
        <link rel="apple-touch-icon-precomposed" href="<?php echo e(url('images/favicon/favicon-32x32.png')); ?>">
        <!-- META DATA-->
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="msapplication-tap-highlight" content="no">
        <meta name="title" content="Forge Admin is modern, responsive Material Admin Template.">
        <meta name="description" content="Forge Admin Material Admin Template is modern, responsive and based on Material Design by Google.It's Material Design Admin Template powered by MaterialCSS.">
        <meta name="keywords" content="materialize, admin template, dashboard template, flat admin template, responsive admin template, materialcss, admin pages, material CMS, Forge Admin template, resoponsive material admin">
        <meta name="msapplication-TileColor" content="#FFFFFF">
        <meta name="msapplication-TileImage" content="<?php echo e(url('images/favicon/favicon-32x32.png')); ?>">
        <meta name="theme-color" content="#2a56c6">



        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Forge Admin')); ?></title>
        <!-- FONTS-->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata" type="text/css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/dynamic.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('plugins/scrollbar/perfect-scrollbar.min.css')); ?>">
        <link href="<?php echo e(asset('css/admin/app.css')); ?>" rel="stylesheet">
        <!-- add by me -->
        <link rel="stylesheet" href="<?php echo e(asset('plugins/datatable/jquery.dataTables.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('plugins/datatable/select.dataTables.min.css')); ?>">   
        <!-- add by me end --> 
        <?php echo $__env->yieldContent('css'); ?>
    </head>
    <body>
        <?php echo $__env->yieldContent('appPre'); ?>
        <div id="app">
            <div id="preloader">
              <div class="preloader-center">
                <div class="dots-loader dot-circle"></div>
              </div>
            </div>
            <header>
                <?php echo $__env->make('admin.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('admin.includes.verticalnav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('admin.includes.horizontal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('admin.includes.notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </header>
            <main>
                <div class="main-header">
                    <div class="sec-page">
                        <div class="page-title">
                        <h2><?php echo e($name); ?></h2>
                        </div>
                    </div>
                    <div class="sec-breadcrumb">
                        <nav class="breadcrumbs-nav left">
                            <div class="nav-wrapper">
                                <div class="col s12" style="    text-align: left;">
                                    <a class="breadcrumb" href="<?php echo e(url('admin/')); ?>">Home</a>
                                    <a class="breadcrumb" href="#"><?php echo e($name); ?></a>
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
                <?php echo $__env->yieldContent('content'); ?>
                <?php echo $__env->make('admin.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </main>
        </div>
        <!-- Scripts -->
        <script type="text/javascript" src="<?php echo e(asset('js/all.js')); ?>"></script>
        <!-- add by me -->
        <script type="text/javascript" src="<?php echo e(asset('plugins/datatable/jquery.dataTables.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('plugins/datatable/dataTables.select.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('plugins/select2/select2.js')); ?>"></script>
        <!-- add by me end -->

        
        <script src="<?php echo e(asset('js/forgeapp.js')); ?>"></script>
        <script src="<?php echo e(asset('js/init.js')); ?>"></script>

        <?php echo $__env->yieldContent('js'); ?>
        
    </body>
</html>
