<?php $__env->startSection('csscontent'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

               <div class="col-lg">
                <div class="tabContentCol">
                  <div class="tab-content">
                  <div class="tab-pane show active">
                    <div class="tabheaderCol">
                      <h2>الاستشارات</h2>
                    </div>
                    <div class="tabDetailCol">
                      <div class="tableSecTab">
                        <div class="table-responsive">
                          <table class="table">
                              <thead>
                                <tr>
                                  <th scope="col">اسم المريض</th>
                                  <th scope="col">تاريخ</th>
                                  <th scope="col">نوع الخدمات</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php foreach($consultants as $consultant){?>
                                <tr>
                                  <td><?php echo e($consultant->name); ?></td>
                                  <td><?php echo e(Carbon\Carbon::parse($consultant->created_at)->format('d/m/Y')); ?></td>
                                  <td>
                                    <div class="tblBtns">
                                      <ul>
                                        <li>
                                          <button type="button" name="button" class="btn btnTabl <?php if($consultant->type == 'typing'){echo 'btn_secondary';}else{echo 'btn_graysec';}?>"><i class="fa fa-comments-o" aria-hidden="true"></i> Chat</button>
                                        </li>
                                        <li>
                                          <button type="button" name="button" class="btn btnTabl <?php if($consultant->type == 'voice'){echo 'btn_secondary';}else{echo 'btn_graysec';}?>"><i class="fa fa-phone" aria-hidden="true"></i> Phone</button>
                                        </li>
                                        <li>
                                          <button type="button" name="button" class="btn btnTabl <?php if($consultant->type == 'video'){echo 'btn_secondary';}else{echo 'btn_graysec';}?>"><i class="fa fa-video-camera" aria-hidden="true"></i> Video</button>
                                        </li>
                                      </ul>
                                    </div>
                                  </td>
                                </tr>
                                <?php }?>
                              </tbody>
                            </table>
                        </div>
                      </div>

                    </div>
                  </div>
                </div>
                </div>
              </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jscontent'); ?>
    <script>
setInterval(function(){
                $.ajax({
                    type: "GET",
                    url: '/getdunreadmessage',
                    success: function(data){
                        $('.unreadcount').text(data);
                    }
                });
    },3000); 
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appdoctor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>