<?php $__env->startSection('csscontent'); ?>
<style>
    .chatone{
        border: 0;
        padding: 10px 20px 10px 20px;
        border-radius: 5px;
        max-inline-size: min-content;
        min-width:70%;
        font-size:18px;
        color:#117E3D;
        background-color:white;
    }
    .chattwo{
        border: 0;
        padding: 10px 20px 10px 10px;
        border-radius: 5px;
        max-inline-size: min-content;
        min-width:70%;
        font-size:18px;
        color:#18468B;
        background-color:white;
    }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

              <div class="col-lg">
                <div class="tabContentCol">
                  <div class="tab-content">
                  <div class="tab-pane fade show active">
                    <div class="tabheaderCol">
                      <h2><img src="<?php echo e(asset('addbyme/images/message.png')); ?>" alt="..." style="width:40px;height:40px;">   تعديل الملف الشخصي</h2>
                    </div>
                    <div class="row" style="padding:10px 30px;">
                        <div class="col-md-2 col-5">
                        <img src="<?php echo e(asset('upload/avata/'.$patient->photo)); ?>" alt="..." style="border-radius:100%;max-width:70px;height:70px;    border-style: ridge;">
                        </div>
                        <div class="col-md-10 col-7" style="padding:inherit"><?php echo e($patient->name); ?></div>
                    </div>
                    <div class="tabDetailCol" style="border-bottom: black;padding: 20px;    background-color:#E8EFF5;  max-height: 800px;overflow-y: scroll;overflow-x: hidden;direction: ltr; border-style: inset;" id="sliberbox" >
                    <div class="row" style="direction: rtl;" id="chatbox">
                    <?php foreach($chats as $chat){?>
                        <?php if($chat->who == 0 && $chat->type == 'text'){?>
                                <div class="col-md-12" style="direction: ltr;">
                                    <p class="chatone">
                                    <?php echo e($chat->text); ?></br><span style="font-size: small;"><?php echo e($chat->created_at); ?>

                                    <?php if($chat->status == "read"){?>
                                        <img src="<?php echo e(asset('addbyme/images/read.png')); ?>" alt="...">
                                    <?php } else {?>
                                        <img src="<?php echo e(asset('addbyme/images/unread.png')); ?>" alt="...">
                                    <?php }?></br>
                                    </span></p>
                                </div>
                        <?php } if($chat->who == 0 && $chat->type != 'text'){?>
                                <div class="col-md-12"  style="direction: ltr;">
                                    <p class="chatone">
                                    <img src="<?php echo e(asset('upload/chat/'.$chat->text)); ?>" ></br><span style="font-size: small;"><?php echo e($chat->created_at); ?>

                                    <?php if($chat->status == "read"){?>
                                        <img src="<?php echo e(asset('addbyme/images/read.png')); ?>" alt="...">
                                    <?php } else {?>
                                        <img src="<?php echo e(asset('addbyme/images/unread.png')); ?>" alt="...">
                                    <?php }?></br>
                                    </span></p>
                                </div>
                        <?php } if($chat->who == 1 && $chat->type == 'text'){?>
                                <div class="col-md-12">
                                    <p class="chattwo">
                                    <?php echo e($chat->text); ?></br><span style="font-size: small;"><?php echo e($chat->created_at); ?>

                                    <?php if($chat->status == "read"){?>
                                        <img src="<?php echo e(asset('addbyme/images/read.png')); ?>" alt="...">
                                    <?php } else {?>
                                        <img src="<?php echo e(asset('addbyme/images/unread.png')); ?>" alt="...">
                                    <?php }?>
                                    </span></p>
                                </div>
                        <?php } if($chat->who == 1 && $chat->type != 'text'){?>
                                <div class="col-md-12">
                                    <p class="chattwo">
                                    <img src="<?php echo e(asset('upload/chat/'.$chat->text)); ?>"></br><span style="font-size: small;"><?php echo e($chat->created_at); ?>

                                    <?php if($chat->status == "read"){?>
                                        <img src="<?php echo e(asset('addbyme/images/read.png')); ?>" alt="...">
                                    <?php } else {?>
                                        <img src="<?php echo e(asset('addbyme/images/unread.png')); ?>" alt="...">
                                    <?php }?></br>
                                    </span></p>
                                </div>
                    <?php } }?>
                    </div>
                    </div>
                    <input type="file" name="photo" style="display:none;"  data-input="false"  data-size="sm" accept="image/*" data-badge="false">
                    <div class="tabDetailCol row" style="border-bottom: black;padding: 20px;   border-style: inset;">
                        <div class="col-md-2 col-3">
                            <div class="formStyle">
                               <img src="<?php echo e(asset('addbyme/images/messagebox.png')); ?>" alt="..." id="sendmessage">
                            </div>
                        </div>
                        <div class="col-md-10 col-9">
                            <div class="formStyle">
                                <textarea  class="form-control"  placeholder="" name="name" placeholder="Text" required style="height:150px;font-size:18px;" id="messagetext"></textarea>
                            </div>
                        </div>
                        <div class="col-md-2 col-3">
                            <div class="formStyle">
                                <a id="bt_doctor_image"><img src="<?php echo e(asset('addbyme/images/attached.png')); ?>" alt="..." ></a>
                            </div>
                        </div>
                        <div class="col-md-6 col-9">
                            <div class="formStyle">
                                <input type="input" class="form-control" id="filename"  placeholder=""required readonly>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="formStyle">
                            <input type="button" class="form-control"   placeholder="" name="name" value="ﺍﻧﻬﺎﺀ ﺍﻻﺳﺘﺸﺎﺭﺓ" required style="background-color:yellow;display:none;">
                            </div>
                        </div>
                    </div>
                  </div>
                </div>
                </div>
              </div>
              <input type="hidden" value="<?php echo e($consultant_id); ?>" id="saveid">
              <input type="hidden" value="0" id="focusone">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jscontent'); ?>
    <script>
    var objDiv = document.getElementById("sliberbox");
    objDiv.scrollTop = objDiv.scrollHeight;
    $('#messagetext').click(function() { 
        $.ajax({
            type:'post',
            url:'/dsetallstatus',
            data: {
                "consultant_id":  $('#saveid').val(),
                "_token": $('meta[name="csrf-token"]').attr('content'),
            },
            success:function(data) { 
            },
            failure:function(){
            }
        });
     });
    $( "#messagetext" ).keyup(function() {
        $.ajax({
            type:'post',
            url:'/dsetallstatus',
            data: {
                "consultant_id":  $('#saveid').val(),
                "_token": $('meta[name="csrf-token"]').attr('content'),
            },
            success:function(data) { 
            },
            failure:function(){
            }
        });
    });
    $('#bt_doctor_image').on('click',function(){
        $('input[name="photo"]').click();
    });
    $('input[name="photo"]').on('change',function(e){
        var file = e.target.files[0];
        var reader = new FileReader();
        reader.onloadend =function(){
            $('#filename').val(file.name);
        }
        reader.readAsDataURL(file);     
    });
    $('#sendmessage').on('click',function(){
        if($('#messagetext').val() != '')
        {
            var html = '';
            html += '<div class="col-md-12">';
            html += '<p class="chattwo">'+$('#messagetext').val()+'</p>';
            html += '</div>';
            $('#chatbox').append(html);
            var objDiv = document.getElementById("sliberbox");
            objDiv.scrollTop = objDiv.scrollHeight;  
            $.ajax({
                type:'post',
                url:'/dsavechatone',
                data: {
                    "consultant_id":  $('#saveid').val(),
                    "text":  $('#messagetext').val(),
                    "type":  'text',
                    "_token": $('meta[name="csrf-token"]').attr('content'),
                },
                success:function(data) { 
                    $('#messagetext').val('');               
                },
                failure:function(){
                }
            });
        }
        if($('#filename').val() !='')
        {
            var dataimg = new FormData();
            dataimg.append("consultant_id", $('#saveid').val());
            dataimg.append("text", $('input[name="photo"]')[0].files[0]);
            dataimg.append("type", $('#filename').val());
            dataimg.append("_token", $('meta[name="csrf-token"]').attr('content'));
            $.ajax({
                type:'post',
                url:'/dsavechatone',
                cache : false,
                contentType : false,
                processType : false,
                processData: false,
                data: dataimg,
                success:function(data) { 
                    console.log(data);
                    var html = '';
                    html +='<div class="col-md-12">';
                    html +='<p class="chattwo"><img src="http://localhost:8000/upload/chat/'+data+'" ></p>';
                    html +='</div>';
                    $('#filename').val('');
                    $('#chatbox').append(html); 
                    var objDiv = document.getElementById("sliberbox");
                    objDiv.scrollTop = objDiv.scrollHeight; 
                                   
                },
                failure:function(){
                }
            });
        }
    })
    
    setInterval(function(){
        $.ajax({
            type:'post',
            url:'/dgetchat',
            data: {
                "consultant_id":  $('#saveid').val(),
                "_token": $('meta[name="csrf-token"]').attr('content'),
            },
            success:function(data) { 
                var data = JSON.parse(data);
                var html ="";
                for(var i =0;i<data.length;i++)
                {
                    if(data[i]['who'] == 0 && data[i]['type'] == 'text'){
                        html +='<div class="col-md-12"  style="direction: ltr;">';
                        html +='<p class="chatone">'+data[i]['text']+'</br><span style="font-size: small;">'+data[i]['created_at'];
                           if(data[i]['status'] == "read")
                           html +='<img src="http://localhost:8000/addbyme/images/read.png" alt="...">';
                           else
                           html +='<img src="http://localhost:8000/addbyme/images/unread.png" alt="...">';
                        
                        html +='</span></p>';
                        html +='</div>';
                    }
                    if(data[i]['who'] == 0 && data[i]['type'] != 'text'){
                        html +='<div class="col-md-12"  style="direction: ltr;">';
                        html +='<p class="chatone"><img src="http://localhost:8000/upload/chat/'+data[i]['text']+'" download></br><span style="font-size: small;">'+data[i]['created_at'];
                           if(data[i]['status'] == "read")
                           html +='<img src="http://localhost:8000/addbyme/images/read.png" alt="...">';
                           else
                           html +='<img src="http://localhost:8000/addbyme/images/unread.png" alt="...">';
                        
                        html +='</span></p>';
                        html +='</div>';
                    }
                    if(data[i]['who'] == 1 && data[i]['type'] == 'text'){
                        html +='<div class="col-md-12">';
                        html +='<p class="chattwo">'+data[i]['text']+'</br><span style="font-size: small;">'+data[i]['created_at'];
                            if(data[i]['status'] == "read")
                           html +='<img src="http://localhost:8000/addbyme/images/read.png" alt="...">';
                           else
                           html +='<img src="http://localhost:8000/addbyme/images/unread.png" alt="...">';
                        
                        html +='</span></p>';
                        html +='</div>';
                    }
                    if(data[i]['who'] == 1 && data[i]['type'] != 'text'){
                        html +='<div class="col-md-12">';
                        html +='<p class="chattwo"><img src="http://localhost:8000/upload/chat/'+data[i]['text']+'"></br><span style="font-size: small;">'+data[i]['created_at'];
                            if(data[i]['status'] == "read")
                           html +='<img src="http://localhost:8000/addbyme/images/read.png" alt="...">';
                           else
                           html +='<img src="http://localhost:8000/addbyme/images/unread.png" alt="...">';
                        
                        html +='</span></p>';
                        html +='</div>';
                    }
                }
                $("#chatbox").empty();
                $("#chatbox").append(html); 
                if($('#focusone').val() != data.length)
                {
                    $('#focusone').val(data.length);
                    var objDiv = document.getElementById("sliberbox");
                    objDiv.scrollTop = objDiv.scrollHeight;
                }
            },
            failure:function(){
            }
        });
    },3000); 
    setInterval(function(){
                $.ajax({
                    type: "GET",
                    url: '/getdunreadmessage',
                    success: function(data){
                        $('.unreadcount').text(data);
                    }
                });
    },3000);       
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.appdoctor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>