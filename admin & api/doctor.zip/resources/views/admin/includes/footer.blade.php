 <footer class="page-footer no-mrpd grey lighten-4">
	<div class="footer-copyright">
	  <div class="container primary-text">© 2018 Hexesis, All rights reserved.
	    <div class="right"><span class="left">Handcrafted with </span><a class="left" href="http://codigoforge.com"><i class="material-icons secondary-text tiny left" style="line-height:20px;margin:0px 8px;">favorite</i>By Hexesis</a></div>
	    </div>
	</div>
</footer>
