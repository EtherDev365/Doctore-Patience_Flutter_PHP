<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class money extends Model
{
    //
}
