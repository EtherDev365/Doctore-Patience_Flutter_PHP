<?php

define('ACTIVE_STATUS', 'active');
define('INACTIVE_STATUS', 'inactive');
define('DEVELOPER_KEY', '1');
define('DEVELOPER_ROLE_KEY', '1');
define('DEVELOPER_PERMISSION_KEY', '1');

// ENVs
define('HTTP_REQ', 'http://');
define('DOMAIN_NAME', 'localhost');
define('SESSION_DOMAIN', '.'.DOMAIN_NAME);
define('APP_URL', HTTP_REQ.DOMAIN_NAME);
define('APP_KEY', '');
